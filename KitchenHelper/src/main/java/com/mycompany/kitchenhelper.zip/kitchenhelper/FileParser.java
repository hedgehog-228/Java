/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.kitchenhelper;

import java.io.IOException;

/**
 *
 * @author Nikol
 */
public interface FileParser {
    Recipe parse(String source) throws IOException; 
    
}
